<?php
    if ($item->tinggi_genangan >= 100) {
        $status = 'Awas';
    } elseif ($item->tinggi_genangan >= 50) {
        $status = 'Siaga';
    } else {
        $status = 'Waspada';
    }
?>

<div class="card">
    <h3><?php echo e($item->lokasi); ?></h3>
    <p>Pelapor: <?php echo e($item->nama_pelapor); ?></p>
    <p>Tinggi genangan: <?php echo e($item->tinggi_genangan); ?> cm</p>
    <p>Tanggal: <?php echo e(\Carbon\Carbon::parse($item->tanggal_kejadian)->format('d-m-Y')); ?></p>
    <span class="badge <?php echo e($status); ?>"><?php echo e($status); ?></span>
</div><?php /**PATH C:\Users\satri\Praktikum04\resources\views/partials/laporan-card.blade.php ENDPATH**/ ?>